<h1><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('browseoffer/index','Browse offers');?></h1>

<h4><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('browseoffer/index','General');?></h4>
<ul class="circle small-list">
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('abstract/list')?>/BrowseOfferInvitation"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('browseoffer/index','Browse your offers');?></a></li>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('browseoffer/htmlcode')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('browseoffer/index','HTML Code');?></a></li>
</ul>