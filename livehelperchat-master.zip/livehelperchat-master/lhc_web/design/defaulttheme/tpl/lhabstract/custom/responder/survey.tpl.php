<div class="form-group">
    <label><?php echo $fields['survey_timeout']['trans'];?></label>
    <?php echo erLhcoreClassAbstract::renderInput('survey_timeout', $fields['survey_timeout'], $object)?>
</div>