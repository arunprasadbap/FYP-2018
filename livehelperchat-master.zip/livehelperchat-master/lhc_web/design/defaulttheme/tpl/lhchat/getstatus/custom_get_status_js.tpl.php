<?php 
/**
 * Custom get status JS
 * */
?>