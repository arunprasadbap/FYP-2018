<?php
    $chatOptionsVariablePage = 'LHCChatOptionsPage';
    $chatCSSPrefix = 'lhc';
?>