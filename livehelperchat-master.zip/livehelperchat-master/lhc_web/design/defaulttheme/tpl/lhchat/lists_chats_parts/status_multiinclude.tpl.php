<?php
/**
 * Multi include status
 * if ($chat->status == erLhcoreClassModelChat::STATUS_OPERATORS_CHAT) : ?>
    <i class="material-icons chat-active">face</i><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/pendingchats','Operators chat');?>
   <?php endif;?>
 **/
?>
