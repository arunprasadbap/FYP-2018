<button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
      <i class="material-icons mr-0">settings_applications</i>
      <span class="caret"></span>
</button>