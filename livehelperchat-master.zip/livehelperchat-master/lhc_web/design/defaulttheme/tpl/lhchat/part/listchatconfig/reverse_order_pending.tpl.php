<?php $attribute = 'reverse_pending';$boolValue = true;?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>