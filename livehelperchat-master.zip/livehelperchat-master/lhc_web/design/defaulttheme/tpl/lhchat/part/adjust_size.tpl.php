<span class="adjust-size">
    <a onclick="return lhinst.changeHeight(<?php echo $chat->id?>,false)" title="<?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/chat','Decrease height')?>" ><i class="material-icons">keyboard_arrow_up</i></a>
    <a onclick="return lhinst.changeHeight(<?php echo $chat->id?>,true)" title="<?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/chat','Increase height')?>" ><i class="material-icons">keyboard_arrow_down</i></a>
</span>

