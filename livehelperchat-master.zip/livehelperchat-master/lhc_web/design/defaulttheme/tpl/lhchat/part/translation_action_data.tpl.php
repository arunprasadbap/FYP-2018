<?php $dataChatTranslation = !isset($dataChatTranslation) ? erLhcoreClassModelChatConfig::fetch('translation_data')->data_value : $dataChatTranslation; ?>
	