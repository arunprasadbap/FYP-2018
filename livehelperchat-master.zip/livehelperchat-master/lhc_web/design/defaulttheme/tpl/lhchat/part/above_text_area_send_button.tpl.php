<div class="user-chatwidget-buttons" id="ChatSendButtonContainer"> 
    <a class="btn btn-default btn-xs" onclick="$('#ChatSendButtonContainer').remove();$('#form-start-chat').submit()" title="<?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/startchat','Send message');?>"><i class="material-icons mr-0">&#xE569;</i></a>
</div>