<?php 
/**
 * Override custom column title
 */
?>