<?php /**
 *
 * Allow to have custom status.
 * In order to stop system rendering it's own status define variable. $customChatStatus = true
 *
 */ ?>