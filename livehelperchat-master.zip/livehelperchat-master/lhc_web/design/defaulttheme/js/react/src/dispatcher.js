import { Dispatcher } from "flux";

export default new Dispatcher;