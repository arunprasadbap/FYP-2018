<?php
$name='';
 session_start(); 
 
 if(isset($_SESSION['name'])){
	 
	$name=$_SESSION['name'];?>
	 

 <div class="alert alert-success">
  <strong><?php echo '<b>'.$name.'</b>'; unset($_SESSION['name']);?></strong> &nbsp;Amount Successfully Updated<a href="balance.php" class="alert-link">&nbsp;View current balance</a>.
</div>
 <?php  }  ?>
 

  <?php  
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "canteen";
$mysqli = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(isset($_SESSION['role']) && $_SESSION['role'] ==1);


?>

<html>

<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Add User Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/layout.css" rel="stylesheet">
    
    

		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
</head>
<body>
<?php require 'navAdmin.php'; ?>
<div class="container">
<form action="addamount2.php" method="POST">
<div class="col-xs-4 col-lg-6 ">  
<label><b>Student/Staff ID</b></label> 
<input type="text" class="form-control" name="id" placeholder="Student/Staff ID">
 
</div>
<div class="col-xs-4 col-lg-6 ">  
<label><b>Amount</b></label> 
<input type="text" class="form-control" name="amount" placeholder="Amount">
 
</div>

<p align="center"><button type="submit"name="viewamount" class="btn btn-default">Submit</button></p>
</form>

</div>





</body>

</html>
<style>

</style>