   <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Cashless Canteen FYP 2018 Team RAT</p>
      </div>
      <!-- /.container -->
    </footer>